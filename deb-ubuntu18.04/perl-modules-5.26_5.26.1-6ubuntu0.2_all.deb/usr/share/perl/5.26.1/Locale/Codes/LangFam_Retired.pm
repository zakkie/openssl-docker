package #
Locale::Codes::LangFam_Retired;

# This file was automatically generated.  Any changes to this file will
# be lost the next time 'deprecate_codes' is run.
#    Generated on: Tue Sep 27 15:40:31 EDT 2011

use strict;
use warnings;
require 5.002;

our($VERSION);
$VERSION='3.42';

$Locale::Codes::Retired{'langfam'}{'alpha'}{'code'} = {
};

$Locale::Codes::Retired{'langfam'}{'alpha'}{'name'} = {
};


1;
